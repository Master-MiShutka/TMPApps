﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace TMP.ARMTES.ViewModel.DataViews
{
    public abstract class BaseDataViewViewModel : BaseViewModel
    {
        public BaseDataViewViewModel()
        {
            UpdateCommand = new DelegateCommand(() =>
            {
                Status = "Получение данных";

                var watch = System.Diagnostics.Stopwatch.StartNew();
                var task = Task.Factory.StartNew(Start);
                task.ContinueWith(t =>
                {
                    watch.Stop();
                    System.Diagnostics.Trace.TraceInformation("Update -> {0} ms", watch.ElapsedMilliseconds);

                    IsBusy = false;
                    Status = null;
                    DetailedStatus = null;
                });
                task.ContinueWith(t =>
                {
                    MessageBox.Show(SmallEngineViewerApp.GetExceptionDetails(t.Exception), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }, TaskContinuationOptions.OnlyOnFaulted);
            });
        }
        public ICommand UpdateCommand { get; internal set; }

        protected virtual void Start()
        {
            ;
        }
    }
}
