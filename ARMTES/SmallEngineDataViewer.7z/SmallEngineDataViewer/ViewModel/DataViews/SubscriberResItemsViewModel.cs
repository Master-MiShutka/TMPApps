﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

using TMP.ARMTES.Model;

namespace TMP.ARMTES.ViewModel.DataViews
{
    public class SubscriberResItemsViewModel : BaseDataViewViewModel
    {
        public SubscriberResItemsViewModel()
        {
            SubscriberResItems = new List<SubscriberResItem>(new SubscriberResItem[]
            {
                new SubscriberResItem() { ResName = "Test Res 1", SubscribersCount = 123 },
                new SubscriberResItem() { ResName = "Test Res 2", SubscribersCount = 456 }
            });
        }

        protected override void Start()
        {
            DetailedStatus = "GetSubscriberResItems";
            {
                PageResult<SubscriberResItem> model = null;
                model = Webservice.GetDataFromArmtes<PageResult<SubscriberResItem>>("api/BillingExportApi/GetSubscriberResItems");
                if (model != null && model.Count > 0)
                {
                    SubscriberResItems = model.Items;
                    RaisePropertyChanged("SubscriberResItems");
                }
            }

            DetailedStatus = "GetResApps";
            {
                PageResult<ResApp> model = null;
                model = Webservice.GetDataFromArmtes<PageResult<ResApp>>("api/BillingExportApi/GetResApp");
                if (model != null && model.Count > 0)
                {
                    ResApps = model.Items;
                    RaisePropertyChanged("ResApps");
                }
            }

            DetailedStatus = "GetUnitedReports";
            {
                PageResult<UnitedReportViewItem> model = null;
                model = Webservice.GetDataFromArmtes<PageResult<UnitedReportViewItem>>("api/BillingExportApi/GetUnitedReport");
                if (model != null && model.Count > 0)
                {
                    UnitedReports = model.Items;
                    RaisePropertyChanged("UnitedReports");
                }
            }
        }

        public ICollection<SubscriberResItem> SubscriberResItems { get; set; }
        public ICollection<ResApp> ResApps { get; set; }

        public ICollection<UnitedReportViewItem> UnitedReports { get; set; }
    }
}
