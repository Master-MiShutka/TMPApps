﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

using TMP.ARMTES.Model;

namespace TMP.ARMTES.ViewModel.DataViews
{
    public class CollectorsApiViewModel : BaseDataViewViewModel
    {
        public CollectorsApiViewModel()
        {
            ;
        }

        protected override void Start()
        {
            DetailedStatus = "Подготовка отчёта по системам";
            {
                PageResult<CollectorDeviceViewModel> model = null;
                model = Webservice.GetDataFromArmtes<PageResult<CollectorDeviceViewModel>>("api/CollectorsApi/Get");
                if (model != null && model.Count > 0)
                {
                    CollectorDevices = model.Items;
                    RaisePropertyChanged("CollectorDevices");
                }
            }
        }

        public ICollection<CollectorDeviceViewModel> CollectorDevices { get; set; }
    }
}
